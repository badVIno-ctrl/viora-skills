# Реальные команды и последовательность
Рабочий корень CLI: `/data/shorts_upgrade/portable-check/shorts`. Интерпретатор `/data/shorts_upgrade/.venv/bin/python`. Команды ниже фактически выполнены (некоторые многократно при ремонте).

## Чтение и инспекция
- `cat /data/shorts_upgrade/portable-check/shorts/SKILL.md`
- Из корня скилла: `cat ROUTER.md reference/advertising.md reference/ad-creative.md reference/ad-offers-traffic.md reference/ad-analytics.md reference/ad-qa.md`
- `cat /skills/artifact-design/SKILL.md`
- Из корня скилла: `cat docs/advertising-source-map.md reference/intake.md reference/niche-entry.md schema/campaign.example.json schema/campaign.schema.json examples/advertising/captions-training.md templates/advertising/{brief,concepts,storyboard,qa,experiment}.md`
- `/data/shorts_upgrade/.venv/bin/python -B tools/shorts.py --help`
- `sed`/`rg` по tools/shorts.py, tools/shortskit/advertising.py, memory.py, config.py и capture_html.py/.mjs. Начальный поиск prefs.py не нашёл такого модуля; фактический модуль памяти — memory.py.
- `fc-match 'DejaVu Sans'`, `fc-match Arial`, `fc-match 'Liberation Sans'`, `fc-list | head -5`. Вывод и исправление описаны в logs/font.txt, render-repair.txt.

## Изоляция
Перед CLI prefs/ad-init установлены PYTHONDONTWRITEBYTECODE=1, SHORTS_MEMORY=/data/shorts_upgrade/agent-validation/memory, SHORTS_CACHE=/data/shorts_upgrade/agent-validation/cache, SHORTS_NETWORK=0, SHORTS_ALLOW_PAID=0. Перед рендером также TMPDIR=/data/shorts_upgrade/agent-validation/tmp и XDG_CACHE_HOME=/data/shorts_upgrade/agent-validation/cache. Рекламные проверки дополнительно имеют SHORTS_HOME=/data/shorts_upgrade/portable-check/shorts. Настройки не сохранялись в исходном скилле.

## Производство
```bash
cd /data/shorts_upgrade/portable-check/shorts
/data/shorts_upgrade/.venv/bin/python -B tools/shorts.py prefs show
/data/shorts_upgrade/.venv/bin/python -B tools/shorts.py ad-init /data/shorts_upgrade/agent-validation/creative
/data/shorts_upgrade/.venv/bin/python -B /data/shorts_upgrade/agent-validation/build_preview.py
```
stdout первых двух команд сохранён в logs/prefs-show.json и logs/ad-init.json.
build_preview.py создал SVG и заполнил документы. После первого визуального открытия шрифт заменён на Arial в созданном скрипте; скрипт повторно выполнен. Новых внешних ассетов не загружали.

## Рендер (каждый helper запускался отдельной командой)
```bash
TMPDIR=/data/shorts_upgrade/agent-validation/tmp XDG_CACHE_HOME=/data/shorts_upgrade/agent-validation/cache PYTHONDONTWRITEBYTECODE=1 /data/shorts_upgrade/.venv/bin/python -B /skills/artifact-design/scripts/capture_html.py /data/shorts_upgrade/agent-validation/creative/preview-mono.svg /data/shorts_upgrade/agent-validation/creative/preview-mono.png --width 1080 --height 1920
TMPDIR=/data/shorts_upgrade/agent-validation/tmp XDG_CACHE_HOME=/data/shorts_upgrade/agent-validation/cache PYTHONDONTWRITEBYTECODE=1 /data/shorts_upgrade/.venv/bin/python -B /skills/artifact-design/scripts/capture_html.py /data/shorts_upgrade/agent-validation/creative/preview.svg /data/shorts_upgrade/agent-validation/creative/preview.png --width 1080 --height 1920
```
Монохромный рендер выполнен дважды: до и после ремонта шрифта. Его первый PNG заменён исправленным; факт первого просмотра зафиксирован в сеансе и qa.md. logs/render-mono.json — последний монохромный рендер, logs/render-final.json — цветной.
Затем inline Python с Pillow выполнил verify/load, SHA-256, resize LANCZOS до 360/390 px и расчёт контраста; результат logs/file-check.json. view_image отдельно открыл обе монохромные версии, цветной PNG и каждое уменьшение.

## Ворота
```bash
/data/shorts_upgrade/.venv/bin/python -B /data/shorts_upgrade/agent-validation/finalize_checks.py
```
Этот скрипт заполнил qa.md/хэш campaign.json, уточнил раскадровку и РЕАЛЬНО выполнил:
```bash
cd /data/shorts_upgrade/portable-check/shorts
/data/shorts_upgrade/.venv/bin/python -B tools/shorts.py ad-check /data/shorts_upgrade/agent-validation/creative --stage draft
/data/shorts_upgrade/.venv/bin/python -B tools/shorts.py ad-check /data/shorts_upgrade/agent-validation/creative --stage launch
```
Точные argv/cwd/env/exit codes: logs/check-commands.json. stdout, stderr и копии ad-qa сохранены отдельно по стадиям. Код скрипта проверил ожидаемые значения assert, это не изменение скилла.

## Сохранность и упаковка
Inline Python до производства снял SHA-256 всех файлов переносимого скилла и ZIP, после ворот пересчитал и сравнил: logs/integrity-before.json, logs/integrity-after.json.
`/data/shorts_upgrade/.venv/bin/python -B /data/shorts_upgrade/agent-validation/write_report.py` создал этот журнал, отчёт, SHA256SUMS и новый agent-validation-results.zip. Это архив результатов, не перевыпуск скилла.
Полный pytest, video render/qa/release-check, платные API, shared browser, публикации и сетевые исследования не запускались.
