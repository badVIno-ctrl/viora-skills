from pathlib import Path
import json,hashlib,subprocess,os
O=Path('/data/shorts_upgrade/agent-validation');D=O/'creative';S=Path('/data/shorts_upgrade/portable-check/shorts');P='/data/shorts_upgrade/.venv/bin/python'
p=D/'preview.png'; sha=hashlib.sha256(p.read_bytes()).hexdigest()
qa=f'''# QA и блокеры — учебное превью
Дата контекста задания: 20.10.2026. Проверяющий: агент текущего сеанса.
Файл preview.png; PNG RGB, 1080×1920 (9:16), 140477 байт.
SHA-256: `{sha}`. Машинные измерения: ../logs/file-check.json.

## Фактически выполнено
- Изображения открыты инструментом view_image: первый монохромный рендер; исправленный монохромный; цветной preview.png; preview-360.png; preview-390.png. Это визуальная инспекция статичных файлов, не просмотр видео и не прослушивание.
- Первый монохромный рендер дал serif fallback вместо требуемого шрифта; заменён на установленный Arial, повторный рендер открыт. См. ../logs/render-repair.txt и font.txt. Исходный скилл не менялся.
- Исправленный монохромный: главный заголовок отделён от примера, блоки не перекрываются, текст внутри рамок.
- Цветной PNG: видны «Учебный макет» и «Вымышленный сервис. Не запись продукта.»; нет обрезания, тесных стыков и чужого логотипа. Синий выделяет результат; ДО/ПОСЛЕ различаются и словами.
- 360×640: виден пропуск «не», читаются CTA и учебная маркировка, переполнений не заметил. 390×693: та же иерархия, исходная строка вмещается, дисклеймер не обрезан. Это внутренние экранные уменьшения, не физический телефон и не проверка зрения пользователей.
- Минимальный кегль при 360 px ~14,7 px. Контраст всех используемых пар текста/фона по формуле WCAG: не ниже 5,73:1, см. file-check.json. Не является полной проверкой доступности.
- Pillow: verify/load успешны; размер/формат/хэш измерены; написанный эталон «Мы не публикуем без проверки.» совпадает с текстом ПОСЛЕ, ДО намеренно пропускает отрицание. Запись голоса не существует, сверка по слуху не проводилась.
- Источники текста и геометрии собственные; внешних фото, видео, логотипов, музыки и ссылок нет. Коммерческая лицензия шрифта и юридические права не верифицированы: rights=false.

## Ручные ворота campaign.qa
| Ключ | Статус | Основание |
|---|---|---|
| product_action | false | Аудитория и учебное действие заданы, реального продукта/оффера нет |
| claims | true | Только проверяемый написанный учебный пример; отсутствуют функции, цены, доход и отзывы |
| rights | false | Происхождение описано, коммерческая правовая проверка не проведена |
| phone_readability | false | Внутренняя инспекция 360/390 выполнена, реальный телефон не проверен |
| overlay_clear | false | Статичный файл без оверлея и лиц; внутренние блоки не пересекаются, реальный UI площадки неизвестен |
| silent_comprehension | true | Статичный текстовый пример; отрицание и исправление видны без звука, это оценка редактора, не тест понимания людьми |
| subtitles | false | Не применимо: PNG без timed-субтитров; показанный текст проверен глазами, аудиоисточника нет; сверка по звуку невозможна |
| motion_audio | false | Не применимо: PNG без движения/звука. Проверены изображения; просмотр MP4 и прослушивание не заявляются |
| cta_route | false | «Сверь с оригиналом» — учебное действие, не кликабельная точка выбранного аккаунта |
| landing | false | Нет ссылки, QR, посадочной и страны запуска |
| disclosure | false | Учебная маркировка есть, действующие правила страны/площадки не исследованы |
| measurement | true | Внутренний план и ограничения прописаны в experiment.md; рекламных результатов нет |

false для неприменимых видеопунктов оставлен намеренно: схема имеет лишь passed:boolean и evidence, явного статуса N/A нет. Это не дефект PNG и не основание подделывать прослушивание. Ручные ворота не объявлены закрытыми для запуска.

## Статус выдачи
Учебное статичное превью. НЕ готово к запуску. Нет публикационного согласия, аккаунта/ГЕО, реального оффера/условий/допуска, юридической проверки, реального UI/телефона, маршрута и посадочной. Ничего не публиковалось и не отправлялось рекламодателям. Не выполнялись покупки, регистрация, платные API.
Для PNG не создаются release.json/MP4, video qa/release-check не запускаются. Применимые проверки: визуальный QA и ad-check. Отчёты draft/launch сохраняются раздельно, так как CLI перезаписывает ad-qa.json.
'''
(D/'qa.md').write_text(qa)
c=json.loads((D/'campaign.json').read_text());c['final_artifact']={'path':'preview.png','sha256':sha}
for k in c['qa']:
 c['qa'][k]={'passed':k in ('claims','silent_comprehension','measurement'),'evidence':'qa.md: ручные ворота '+k+'; ограничения явно сохранены'}
(D/'campaign.json').write_text(json.dumps(c,ensure_ascii=False,indent=2)+'\n')
# Correct explanatory coordinates/text without changing the visual artifact.
f=D/'storyboard.md';t=f.read_text();t=t.replace('Мы не публикуем / без проверки. | Синтетический эталон','Мы не публикуем без проверки. | Синтетический эталон').replace('заголовок y=300/402; эталон y=588','заголовок y=332/434; подзаголовок y=514/574; метка эталона y=662, текст y=724');f.write_text(t)
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',SHORTS_HOME=str(S),SHORTS_MEMORY=str(O/'memory'),SHORTS_CACHE=str(O/'cache'),SHORTS_NETWORK='0',SHORTS_ALLOW_PAID='0',TMPDIR=str(O/'tmp'),XDG_CACHE_HOME=str(O/'cache'))
results=[]
for stage in ('draft','launch'):
 cmd=[P,'-B','tools/shorts.py','ad-check',str(D),'--stage',stage]
 r=subprocess.run(cmd,cwd=S,env=env,text=True,capture_output=True)
 (O/f'logs/ad-check-{stage}.stdout.json').write_text(r.stdout);(O/f'logs/ad-check-{stage}.stderr.txt').write_text(r.stderr)
 (O/f'logs/ad-qa-{stage}.json').write_bytes((D/'ad-qa.json').read_bytes())
 rep=json.loads(r.stdout);results.append({'command':cmd,'cwd':str(S),'exit_code':r.returncode,'stage':stage,'valid':rep['valid'],'ready_for_launch':rep['ready_for_launch'],'issues':len(rep['issues'])})
 assert rep['ready_for_launch'] is False
 if stage=='draft': assert r.returncode==0 and rep['valid'] is True
 else: assert r.returncode==1 and 'training product cannot launch' in rep['issues']
(O/'logs/check-commands.json').write_text(json.dumps({'environment':{k:env[k] for k in ('PYTHONDONTWRITEBYTECODE','SHORTS_HOME','SHORTS_MEMORY','SHORTS_CACHE','SHORTS_NETWORK','SHORTS_ALLOW_PAID','TMPDIR','XDG_CACHE_HOME')},'results':results},indent=2))
print(json.dumps(results,indent=2))
